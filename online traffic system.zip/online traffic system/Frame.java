public class Frame{
public void Paint (Graphics g) {
            g.drawRect(100, 105, 110, 270);
            g.drawOval(120, 150, 60, 60);
            g.drawOval(120, 230, 60, 60);
            g.drawOval(120, 300, 60, 60);
            if(x==1){
                g.setColor(Color.RED);
                g.fillOval(120,150,60,60);
                g.setColor(color.WHITE);
                g.fillOval(120,230,60,60);
                g.setColor(color.WHITE);
                g.fillOval(120,300,60,60);
                x=0;
            }
            if(y==1){
                g.setColor(color.WHITE);
                g.fillOval(120,150,60,60);
                g.setColor(color.YELLOW);
                g.fillOval(120,230,60,60);
                g.setColor(color.WHITE);
                g.fillOval(120,300,60,60);
                y=0;
            }
            if(z==1){
                g.setColor(color.WHITE);
                g.fillOval(120,150,60,60);
                g.setColor(color.WHITE);
                g.fillOval(120,230,60,60);
                g.setColor(color.GREEN);
                g.fillOval(120,300,60,60);
                Z=0;
            }
        }
        public static void main(String args[]) {
            Frame jf = new trafic("Trafic light");
            jf.setSize(500,500);
            jf.setVisible(true);
            
        }
    }