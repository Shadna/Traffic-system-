import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
public class trafic extends Frame implements Items{
    RadioButton jr1;
    RadioButton jr2;
    RadioButton jr3;
    TextField j1 = new TextField(10);
    ButtonGroup b = new ButtonGroup();
    String msg = " ";
    int x=0, y=0, z=0;
    public trafic(String msg){
        super(msg);
        setLayout(new FlowLayout());
        jr1 = new RadioButton("Red");
        jr2 = new RadioButton("Yellow");
        jr3 = new RadioButton("Green");

        jr1.addItems(this);
        jr2.addItems(this);
        jr3.addItems(this);
        add(jr1);
        add(jr2);
        add(jr3);
        b.add(jr1);
        b.add(jr2);
        b.add(jr3);
        add(j1);

        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
    
    }
 }
