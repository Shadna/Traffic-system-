import java.util.*;
public class Items{
public void itemStateChanged(ItemEvent ie){
     
        if(ie.getSource() == jr1){
            if(ie.getStateChange() == 1){
                msg = "Stop!";
                x=1;
                repaint();
            }
            else{
                msg = " ";
            }
        }
        if(ie.getSource() ==jr2){
            if(ie.getStateChange() ==1){
                msg="Get Ready to go!";
                y=1;
                repaint();
            }
            else{
                msg="";
            }
        }
        if(ie.getSource() ==jr3){
            if(ie.getStateChange() ==1){
                msg="Goo!!";
                z=1;
                repaint();
            }
            else{
                msg="";
            }
        }
    }
}